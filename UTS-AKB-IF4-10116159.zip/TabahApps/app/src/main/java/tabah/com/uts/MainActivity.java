package tabah.com.uts;



/*
5/21/2019 10116159 Muhammad Tabah Perkasa HP (IF-4)
*/

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.labawsrh.aws.introscreen.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
